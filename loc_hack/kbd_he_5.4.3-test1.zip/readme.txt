Hebrew localization for Kindle Paperwhite 2
============================================
