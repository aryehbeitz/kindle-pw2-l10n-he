About Translation	
Aeroplane Mode must be turned off to use this feature.	
An error occurred. Please try again.	
Back to Translation	
Chinese Simplified	
Chinese Traditional	
Czech	
Danish	
Detecting...	
Dutch	
English	
Finnish	
French	
From:	
German	
Greek	
Hebrew	
Hindi	
Italian	
Japanese	
Korean	
Latin	
No network detected. Please check your connection and try again.	
No text was selected for translation.	
Norwegian	
Polish	
Portuguese	
Russian	
Slovak	
Spanish	
To:	
Translating your selection...	
Translation	
Turkish	
Turn Off Aeroplane Mode	
Ukrainian	
Unable to contact the server. Please try again later.	
Unknown	
Waiting for connection...	
Wireless must be turned on to use this feature.	
