A customer support specialist will look into this error. You will be able to view the status on your profile page on kindle.amazon.com the next time this device synchronises with Amazon.	
A customer support specialist will look into this error.	
Add Optional Comments.	
Cancel	בטל#or#ביטול
Formatting	
Image	
Other	
Report Content Error	
Report your selection as having an error.	
Thank You	
The reporting of content errors is not possible with this content.	
Typo	
