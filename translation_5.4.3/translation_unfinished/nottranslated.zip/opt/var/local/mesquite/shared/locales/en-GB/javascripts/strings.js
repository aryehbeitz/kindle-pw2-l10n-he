Cancel	בטל#or#ביטול
Connection Required	
Menu	
OK	
Remove	
Shop in Kindle Store	לחנות קינדל#or#לקניות בחנות קינדל
Unable to Connect	
Your Kindle is currently unable to connect.<br><br>Please try again later.	
strings	
