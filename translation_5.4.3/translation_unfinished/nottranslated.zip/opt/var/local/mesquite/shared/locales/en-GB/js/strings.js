Cancel	בטל#or#ביטול
Connection Required	
Lock Rotation	
Menu	
OK	
Register	
Remove	
Shop in Kindle Store	לחנות קינדל#or#לקניות בחנות קינדל
This action requires wireless to be turned on.	
Unable to Connect	
Unlock Rotation	
Your Kindle is currently unable to connect.<br><br>Please try again later.	
