Enter Text	
Okay	
Sample Custom Dialog	
This is just a sample dialog	
