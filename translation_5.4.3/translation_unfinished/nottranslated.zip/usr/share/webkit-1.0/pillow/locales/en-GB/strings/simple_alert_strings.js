Active Content Locked	
Aeroplane Mode Locked	
Aeroplane Mode	
An unexpected error has occurred. This can happen if you recently disconnected your Kindle from a computer without ejecting it safely. Please wait while your Kindle attempts to resolve this error.	
An update is available for the following fonts: ({language}). Your Kindle must restart to complete the update.	
Application Error	
Battery Level is Low	
Cancel	בטל#or#ביטול
Cloud Locked	
Debugging Scripts	
Details for this Special Offer are no longer available. Turn on wireless to receive the latest content.	
Details for this Special Offer are no longer available.	
Details for this Special Offer are not available while Parental Controls are enabled.	
Device Error	
Device Not Registered	
Device Reset Pending	
Device Restart Pending	
Error Starting Content	
Error	
Extended debugging scripts are currently enabled	
Framework Error	
Goodreads on Kindle Locked	
Java Heap Low	
Kindle Special Offers	
Kindle Store Locked	
MP3 Player Locked	
No MP3 Files Found	
OK	
Offer Expired	
Parental Controls are enabled on your Kindle. Access to Cloud is locked.	
Parental Controls are enabled on your Kindle. Access to Goodreads on Kindle is locked.	
Parental Controls are enabled on your Kindle. Kindle Store is locked.	
Parental Controls are enabled on your Kindle. Purchases are not allowed.	
Parental Controls are enabled on your Kindle. Web Browser is locked.	
Please select from the following options:	
Power	
Purchase Limit Reached	
Purchases Pending	
Purchasing Locked	
Restart Required	
Restart	
Restarting your Kindle	
Screen Off	
Settings Menu Locked	
Shipping Mode Failed	
Social Networks Locked	
The Java Heap has been low for too long.	
The Wi-Fi network you are connecting to requires you to sign in before accessing the Internet. Do you wish to go to the Web Browser to sign in to: {essid}?	
The Wi-Fi network you are connecting to requires you to sign in before accessing the Internet. Do you wish to go to the Web Browser to sign in?	
The application is not responding. Please wait while your Kindle restarts.	
The item failed to close properly. Unless you close this dialog box your device will restart in {restartTime,plural,=0 {# seconds} one {# second} other {# seconds}}.	
The selected application could not be started. Please try again.	
The selected content could not be opened. Please try again.	
The title could not be opened.	
There is not enough Kindle memory to add or edit notes or marks for this document. Please make more Kindle memory available by removing content from the Home screen.	
This Kindle has been instructed to restart. This process will begin shortly. Please wait until the device has fully restarted.	
This is a managed device. Access to Cloud is locked. For information, contact: {contactInfo}.	
This is a managed device. Access to Goodreads on Kindle is locked. For information, contact: {contactInfo}.	
This is a managed device. Active Content is locked. For information, contact: {contactInfo}.	
This is a managed device. Aeroplane Mode is locked. For information, contact: {contactInfo}.	
This is a managed device. It has been instructed to reset to factory defaults, which will remove all downloaded and transferred content. This process will begin shortly. Please wait until this process is complete. For information, contact: {contactInfo}.	
This is a managed device. Kindle Store is locked. For information, contact: {contactInfo}.	
This is a managed device. MP3 Player is locked. For information, contact: {contactInfo}.	
This is a managed device. Settings Menu is locked. For information, contact: {contactInfo}.	
This is a managed device. Social Network access is locked. For information, contact: {contactInfo}.	
This is a managed device. Toggle Wireless is locked. For information, contact: {contactInfo}.	
This is a managed device. Web Browser is locked. For information, contact: {contactInfo}.	
This is a managed device. Wi-Fi Settings configuration is locked. For information, contact: {contactInfo}.	
To play MP3 files, you must first copy them from your computer to the "music" folder on your Kindle.	
Toggle Wireless Locked	
Turn On Wireless?	
Unable to Open Content	
Unable to enter shipping mode owing to battery level falling below permissible range.	
Unable to enter shipping mode owing to missing dictionaries or fonts.	
Update Later	
Update Now	
Updating Fonts	
Very Low Battery	
We are unable to process your request. Please try again later.	
Web Browser Locked	
Wi-Fi Login Required	
Wi-Fi Settings Locked	
Wireless is turned off. Do you want to turn on wireless?	
You already have {count,plural,=0 {no orders pending} one {an order pending} other { # orders pending}} for this special offer.	
You must register your Kindle to make a purchase.	
Your Kindle fonts are updating. This can take a moment...	
Your Kindle is unable to establish a wireless connection. Do you want to turn off Aeroplane Mode?	
Your battery is almost depleted and your Kindle will soon shut down. To continue using your Kindle, connect it to a power source.	
Your battery is running low. Please charge your Kindle. If your wireless is turned on, try turning it off to extend your reading time.	
Your battery is running low. Please charge your Kindle.	
Your purchase could not be completed. This offer has expired.	
Your purchase could not be completed. We are experiencing technical difficulties. Please try again later.	
Your purchase could not be completed. You have reached the maximum purchase quantity.	
