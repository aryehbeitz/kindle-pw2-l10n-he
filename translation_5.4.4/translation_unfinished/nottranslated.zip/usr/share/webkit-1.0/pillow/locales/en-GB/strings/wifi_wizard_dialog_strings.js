Cancel	בטל#or#ביטול
Connected	התחבר#or#מחובר
Done	בוצע#or#סיום#or#סיים
Error	שגיעה#or#תקלה
Hide Password	הסתר סיסמא#or#הסתר סיסמה
Personal	Personal#or#אישי
Try Again	נסה שוב#or#נסה שנית
