Enter Passcode	הזן את הסיסמה#or#הקש סיסמא
Incorrect Passcode	סיסמא שגויה#or#סיסמה שגויה
