Cancel	בטל#or#ביטול
Error	שגיעה#or#תקלה
Parental Controls are enabled on your Kindle. Purchases are not allowed.	בקרת הורים מופעלות על הקינדל שלך. רכישות אינן מאושרות.#or#בקרת הורים מופעלת על קינדל שלך. רכישות לא מורשות.
Restart	הפעלה מחדש#or#הפעל מחדש
Turn On Wireless?	הפעל אלחוטי?#or#כבה אלחוטי?
You must register your Kindle to make a purchase.	אתה חייב לרשום את קינדל שלך כדי לבצע רכישה.#or#קינדל שלך חייבת להיות רשומה כדי לבצע רכישה.
