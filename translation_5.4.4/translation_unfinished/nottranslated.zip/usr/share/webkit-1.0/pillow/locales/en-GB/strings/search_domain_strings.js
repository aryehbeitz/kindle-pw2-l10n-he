All Text	כל הטקסט#or#כל טקסט
My Items	הפריטים שלי#or#פריטים שלי
