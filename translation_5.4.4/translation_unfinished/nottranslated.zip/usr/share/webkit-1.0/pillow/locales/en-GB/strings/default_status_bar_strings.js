Connected	התחבר#or#מחובר
