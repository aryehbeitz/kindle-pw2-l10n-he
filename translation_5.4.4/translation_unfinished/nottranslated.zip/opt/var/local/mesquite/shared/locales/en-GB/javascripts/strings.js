Cancel	בטל#or#ביטול
Shop in Kindle Store	לחנות קינדל#or#לקניות בחנות קינדל
