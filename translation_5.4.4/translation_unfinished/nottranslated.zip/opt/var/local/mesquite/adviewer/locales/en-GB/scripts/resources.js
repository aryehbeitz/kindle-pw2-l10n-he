Details for this advert are no longer available.	פרטים למודעה זו אינם זמינים עוד.#or#פרטים על הפרסומת כבר אינם זמינים
Error	שגיעה#or#תקלה
Parental Controls are enabled on your Kindle. Purchases are not allowed.	בקרת הורים מופעלות על הקינדל שלך. רכישות אינן מאושרות.#or#בקרת הורים מופעלת על קינדל שלך. רכישות לא מורשות.
You must register your Kindle to make a purchase.	אתה חייב לרשום את קינדל שלך כדי לבצע רכישה.#or#קינדל שלך חייבת להיות רשומה כדי לבצע רכישה.
