Full Wikipedia Article	מאמר ויקיפדיה מלא#or#מאמר ויקיפידיה מלא
More on Shelfari	עוד ב Shelfari#or#עוד בשלפארי
