Cancel	בטל#or#ביטול
Report Content Error	דווח על שגיעה בתוכן#or#דווח שגיעה בתוכן
