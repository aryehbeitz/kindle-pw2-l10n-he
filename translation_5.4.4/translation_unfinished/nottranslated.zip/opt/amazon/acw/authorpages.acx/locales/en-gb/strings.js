About ${author}	
Full Wikipedia Article	מאמר ויקיפדיה מלא#or#מאמר ויקיפידיה מלא
Kindle books by ${author}	
Other books by ${author}	
This page is currently unavailable.	
